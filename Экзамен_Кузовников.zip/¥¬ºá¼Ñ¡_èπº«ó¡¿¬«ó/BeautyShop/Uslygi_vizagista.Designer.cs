﻿namespace BeatyShop
{
    partial class Uslygi_vizagista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Uslygi_vizagista));
            this.beauty_shopDataSet = new BeatyShop.beauty_shopDataSet();
            this.uslygi_vizagistaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.uslygi_vizagistaTableAdapter = new BeatyShop.beauty_shopDataSetTableAdapters.Uslygi_vizagistaTableAdapter();
            this.tableAdapterManager = new BeatyShop.beauty_shopDataSetTableAdapters.TableAdapterManager();
            this.uslygi_vizagistaBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.uslygi_vizagistaBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.uslygi_vizagistaDataGridView = new System.Windows.Forms.DataGridView();
            this.button6 = new System.Windows.Forms.Button();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.beauty_shopDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uslygi_vizagistaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uslygi_vizagistaBindingNavigator)).BeginInit();
            this.uslygi_vizagistaBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uslygi_vizagistaDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // beauty_shopDataSet
            // 
            this.beauty_shopDataSet.DataSetName = "beauty_shopDataSet";
            this.beauty_shopDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // uslygi_vizagistaBindingSource
            // 
            this.uslygi_vizagistaBindingSource.DataMember = "Uslygi_vizagista";
            this.uslygi_vizagistaBindingSource.DataSource = this.beauty_shopDataSet;
            // 
            // uslygi_vizagistaTableAdapter
            // 
            this.uslygi_vizagistaTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ClientsTableAdapter = null;
            this.tableAdapterManager.Nogtevoi_serviceTableAdapter = null;
            this.tableAdapterManager.Parechmacherscie_uslygiTableAdapter = null;
            this.tableAdapterManager.SotrudnikiTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = BeatyShop.beauty_shopDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.Uslygi_vizagistaTableAdapter = this.uslygi_vizagistaTableAdapter;
            // 
            // uslygi_vizagistaBindingNavigator
            // 
            this.uslygi_vizagistaBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.uslygi_vizagistaBindingNavigator.BindingSource = this.uslygi_vizagistaBindingSource;
            this.uslygi_vizagistaBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.uslygi_vizagistaBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.uslygi_vizagistaBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.uslygi_vizagistaBindingNavigatorSaveItem});
            this.uslygi_vizagistaBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.uslygi_vizagistaBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.uslygi_vizagistaBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.uslygi_vizagistaBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.uslygi_vizagistaBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.uslygi_vizagistaBindingNavigator.Name = "uslygi_vizagistaBindingNavigator";
            this.uslygi_vizagistaBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.uslygi_vizagistaBindingNavigator.Size = new System.Drawing.Size(401, 25);
            this.uslygi_vizagistaBindingNavigator.TabIndex = 0;
            this.uslygi_vizagistaBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Добавить";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Удалить";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // uslygi_vizagistaBindingNavigatorSaveItem
            // 
            this.uslygi_vizagistaBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.uslygi_vizagistaBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("uslygi_vizagistaBindingNavigatorSaveItem.Image")));
            this.uslygi_vizagistaBindingNavigatorSaveItem.Name = "uslygi_vizagistaBindingNavigatorSaveItem";
            this.uslygi_vizagistaBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.uslygi_vizagistaBindingNavigatorSaveItem.Text = "Сохранить данные";
            this.uslygi_vizagistaBindingNavigatorSaveItem.Click += new System.EventHandler(this.uslygi_vizagistaBindingNavigatorSaveItem_Click);
            // 
            // uslygi_vizagistaDataGridView
            // 
            this.uslygi_vizagistaDataGridView.AutoGenerateColumns = false;
            this.uslygi_vizagistaDataGridView.BackgroundColor = System.Drawing.Color.Tan;
            this.uslygi_vizagistaDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.uslygi_vizagistaDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.uslygi_vizagistaDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.uslygi_vizagistaDataGridView.DataSource = this.uslygi_vizagistaBindingSource;
            this.uslygi_vizagistaDataGridView.Location = new System.Drawing.Point(30, 41);
            this.uslygi_vizagistaDataGridView.Name = "uslygi_vizagistaDataGridView";
            this.uslygi_vizagistaDataGridView.Size = new System.Drawing.Size(342, 220);
            this.uslygi_vizagistaDataGridView.TabIndex = 1;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.SaddleBrown;
            this.button6.Font = new System.Drawing.Font("Segoe Script", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button6.Location = new System.Drawing.Point(267, 397);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(122, 41);
            this.button6.TabIndex = 8;
            this.button6.Text = "Назад";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Nazvanie";
            this.dataGridViewTextBoxColumn1.HeaderText = "Nazvanie";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 150;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Price";
            this.dataGridViewTextBoxColumn2.HeaderText = "Price";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 150;
            // 
            // Uslygi_vizagista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Tan;
            this.ClientSize = new System.Drawing.Size(401, 450);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.uslygi_vizagistaDataGridView);
            this.Controls.Add(this.uslygi_vizagistaBindingNavigator);
            this.Name = "Uslygi_vizagista";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Uslygi_vizagista";
            this.Load += new System.EventHandler(this.Uslygi_vizagista_Load);
            ((System.ComponentModel.ISupportInitialize)(this.beauty_shopDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uslygi_vizagistaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uslygi_vizagistaBindingNavigator)).EndInit();
            this.uslygi_vizagistaBindingNavigator.ResumeLayout(false);
            this.uslygi_vizagistaBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uslygi_vizagistaDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private beauty_shopDataSet beauty_shopDataSet;
        private System.Windows.Forms.BindingSource uslygi_vizagistaBindingSource;
        private beauty_shopDataSetTableAdapters.Uslygi_vizagistaTableAdapter uslygi_vizagistaTableAdapter;
        private beauty_shopDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator uslygi_vizagistaBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton uslygi_vizagistaBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView uslygi_vizagistaDataGridView;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
    }
}