﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BeatyShop
{
    public partial class Uslygi_vizagista : Form
    {
        public Uslygi_vizagista()
        {
            InitializeComponent();
        }

        private void uslygi_vizagistaBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.uslygi_vizagistaBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.beauty_shopDataSet);

        }

        private void Uslygi_vizagista_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "beauty_shopDataSet.Uslygi_vizagista". При необходимости она может быть перемещена или удалена.
            this.uslygi_vizagistaTableAdapter.Fill(this.beauty_shopDataSet.Uslygi_vizagista);

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            Hide();
        }
    }
}
