﻿namespace BeatyShop
{
    partial class Parechmacherscie_ulsygi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Parechmacherscie_ulsygi));
            this.beauty_shopDataSet = new BeatyShop.beauty_shopDataSet();
            this.parechmacherscie_uslygiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.parechmacherscie_uslygiTableAdapter = new BeatyShop.beauty_shopDataSetTableAdapters.Parechmacherscie_uslygiTableAdapter();
            this.tableAdapterManager = new BeatyShop.beauty_shopDataSetTableAdapters.TableAdapterManager();
            this.parechmacherscie_uslygiBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.parechmacherscie_uslygiBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.parechmacherscie_uslygiDataGridView = new System.Windows.Forms.DataGridView();
            this.button6 = new System.Windows.Forms.Button();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.beauty_shopDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.parechmacherscie_uslygiBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.parechmacherscie_uslygiBindingNavigator)).BeginInit();
            this.parechmacherscie_uslygiBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.parechmacherscie_uslygiDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // beauty_shopDataSet
            // 
            this.beauty_shopDataSet.DataSetName = "beauty_shopDataSet";
            this.beauty_shopDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // parechmacherscie_uslygiBindingSource
            // 
            this.parechmacherscie_uslygiBindingSource.DataMember = "Parechmacherscie_uslygi";
            this.parechmacherscie_uslygiBindingSource.DataSource = this.beauty_shopDataSet;
            // 
            // parechmacherscie_uslygiTableAdapter
            // 
            this.parechmacherscie_uslygiTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ClientsTableAdapter = null;
            this.tableAdapterManager.Nogtevoi_serviceTableAdapter = null;
            this.tableAdapterManager.Parechmacherscie_uslygiTableAdapter = this.parechmacherscie_uslygiTableAdapter;
            this.tableAdapterManager.SotrudnikiTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = BeatyShop.beauty_shopDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.Uslygi_vizagistaTableAdapter = null;
            // 
            // parechmacherscie_uslygiBindingNavigator
            // 
            this.parechmacherscie_uslygiBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.parechmacherscie_uslygiBindingNavigator.BindingSource = this.parechmacherscie_uslygiBindingSource;
            this.parechmacherscie_uslygiBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.parechmacherscie_uslygiBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.parechmacherscie_uslygiBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.parechmacherscie_uslygiBindingNavigatorSaveItem});
            this.parechmacherscie_uslygiBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.parechmacherscie_uslygiBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.parechmacherscie_uslygiBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.parechmacherscie_uslygiBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.parechmacherscie_uslygiBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.parechmacherscie_uslygiBindingNavigator.Name = "parechmacherscie_uslygiBindingNavigator";
            this.parechmacherscie_uslygiBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.parechmacherscie_uslygiBindingNavigator.Size = new System.Drawing.Size(401, 25);
            this.parechmacherscie_uslygiBindingNavigator.TabIndex = 0;
            this.parechmacherscie_uslygiBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Добавить";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Удалить";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // parechmacherscie_uslygiBindingNavigatorSaveItem
            // 
            this.parechmacherscie_uslygiBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.parechmacherscie_uslygiBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("parechmacherscie_uslygiBindingNavigatorSaveItem.Image")));
            this.parechmacherscie_uslygiBindingNavigatorSaveItem.Name = "parechmacherscie_uslygiBindingNavigatorSaveItem";
            this.parechmacherscie_uslygiBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.parechmacherscie_uslygiBindingNavigatorSaveItem.Text = "Сохранить данные";
            this.parechmacherscie_uslygiBindingNavigatorSaveItem.Click += new System.EventHandler(this.parechmacherscie_uslygiBindingNavigatorSaveItem_Click);
            // 
            // parechmacherscie_uslygiDataGridView
            // 
            this.parechmacherscie_uslygiDataGridView.AutoGenerateColumns = false;
            this.parechmacherscie_uslygiDataGridView.BackgroundColor = System.Drawing.Color.Tan;
            this.parechmacherscie_uslygiDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.parechmacherscie_uslygiDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.parechmacherscie_uslygiDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.parechmacherscie_uslygiDataGridView.DataSource = this.parechmacherscie_uslygiBindingSource;
            this.parechmacherscie_uslygiDataGridView.Location = new System.Drawing.Point(31, 43);
            this.parechmacherscie_uslygiDataGridView.Name = "parechmacherscie_uslygiDataGridView";
            this.parechmacherscie_uslygiDataGridView.Size = new System.Drawing.Size(343, 220);
            this.parechmacherscie_uslygiDataGridView.TabIndex = 1;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.SaddleBrown;
            this.button6.Font = new System.Drawing.Font("Segoe Script", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button6.Location = new System.Drawing.Point(267, 396);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(122, 42);
            this.button6.TabIndex = 8;
            this.button6.Text = "Назад";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Nazvanie";
            this.dataGridViewTextBoxColumn1.HeaderText = "Nazvanie";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 150;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Price";
            this.dataGridViewTextBoxColumn2.HeaderText = "Price";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 150;
            // 
            // Parechmacherscie_ulsygi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Tan;
            this.ClientSize = new System.Drawing.Size(401, 450);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.parechmacherscie_uslygiDataGridView);
            this.Controls.Add(this.parechmacherscie_uslygiBindingNavigator);
            this.Name = "Parechmacherscie_ulsygi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Parechmacherscie_ulsygi";
            this.Load += new System.EventHandler(this.Parechmacherscie_ulsygi_Load);
            ((System.ComponentModel.ISupportInitialize)(this.beauty_shopDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.parechmacherscie_uslygiBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.parechmacherscie_uslygiBindingNavigator)).EndInit();
            this.parechmacherscie_uslygiBindingNavigator.ResumeLayout(false);
            this.parechmacherscie_uslygiBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.parechmacherscie_uslygiDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private beauty_shopDataSet beauty_shopDataSet;
        private System.Windows.Forms.BindingSource parechmacherscie_uslygiBindingSource;
        private beauty_shopDataSetTableAdapters.Parechmacherscie_uslygiTableAdapter parechmacherscie_uslygiTableAdapter;
        private beauty_shopDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator parechmacherscie_uslygiBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton parechmacherscie_uslygiBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView parechmacherscie_uslygiDataGridView;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
    }
}