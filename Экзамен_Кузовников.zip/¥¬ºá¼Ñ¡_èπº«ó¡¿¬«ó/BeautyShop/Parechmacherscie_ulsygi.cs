﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BeatyShop
{
    public partial class Parechmacherscie_ulsygi : Form
    {
        public Parechmacherscie_ulsygi()
        {
            InitializeComponent();
        }

        private void parechmacherscie_uslygiBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.parechmacherscie_uslygiBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.beauty_shopDataSet);

        }

        private void Parechmacherscie_ulsygi_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "beauty_shopDataSet.Parechmacherscie_uslygi". При необходимости она может быть перемещена или удалена.
            this.parechmacherscie_uslygiTableAdapter.Fill(this.beauty_shopDataSet.Parechmacherscie_uslygi);

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            Hide();
        }
    }
}
