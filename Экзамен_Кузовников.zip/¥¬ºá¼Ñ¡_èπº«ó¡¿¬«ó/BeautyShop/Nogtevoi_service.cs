﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BeatyShop
{
    public partial class Nogtevoi_service : Form
    {
        public Nogtevoi_service()
        {
            InitializeComponent();
        }

        private void nogtevoi_serviceBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.nogtevoi_serviceBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.beauty_shopDataSet);

        }

        private void Nogtevoi_service_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "beauty_shopDataSet.Nogtevoi_service". При необходимости она может быть перемещена или удалена.
            this.nogtevoi_serviceTableAdapter.Fill(this.beauty_shopDataSet.Nogtevoi_service);

        }

        private void nogtevoi_serviceDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            Hide();
        }
    }
}
