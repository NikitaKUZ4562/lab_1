﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BeatyShop
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Nogtevoi_service nogtevoi_Service = new Nogtevoi_service();
            nogtevoi_Service.Show();
            Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Parechmacherscie_ulsygi parechmacherscie_Ulsygi = new Parechmacherscie_ulsygi();
            parechmacherscie_Ulsygi.Show();
            Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Clients clients = new Clients();
            clients.Show();
            Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Uslygi_vizagista uslygi_Vizagista = new Uslygi_vizagista();
            uslygi_Vizagista.Show();
            Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Sotrudniki sotrudniki = new Sotrudniki();
            sotrudniki.Show();
            Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Main_form main_Form = new Main_form();
            main_Form.Show();
            Hide();
        }
    }
}
